﻿using System;

namespace MemoryMappedDatabase
{
    public class DuplicateTableException : Exception
    {
    }
}