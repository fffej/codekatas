﻿namespace MemoryMappedDatabase
{
    public enum ColumnType
    {
        Int,
        Bool
    }
}