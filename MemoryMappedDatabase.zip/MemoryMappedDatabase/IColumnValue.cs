﻿namespace MemoryMappedDatabase
{
    public interface IColumnValue
    {
    }
}