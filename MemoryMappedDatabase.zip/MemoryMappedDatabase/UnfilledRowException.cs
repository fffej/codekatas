﻿using System;

namespace MemoryMappedDatabase
{
    public class UnfilledRowException : Exception
    {
    }
}